//
//  TJBeachBallSpinner.m
//  CoreAnimationStuff
//
//  Created by Aparna Bhat on 22/08/12.
//  Copyright (c) 2012 TechJini Solutions Pvt. Ltd. All rights reserved.
//

#import "TJBeachBallSpinner.h"


@implementation TJBeachBallSpinner

@synthesize radius = _radius;
@synthesize segments = _segments;
@synthesize segmentColors = _segmentColors;


#pragma mark -
#pragma mark Private methods
- (void) drawSegmentForIndex:(int)index startAngle:(CGFloat)startAngle endAngle:(CGFloat)endAngle
{
    
    CGPoint centerPoint = CGPointMake(self.frame.size.width/2, self.frame.size.height/2);
    CGContextRef context = UIGraphicsGetCurrentContext();

    int colorIndex = index;
    
    if (colorIndex>=_segments) 
    {
        colorIndex = colorIndex - _segments;
    }
    
     //UIColor *color = [self colorForSegment:_segmentIndex+index*(-1)];
    UIColor *color = [_segmentColors objectAtIndex:colorIndex];
    CGMutablePathRef path = CGPathCreateMutable();
    CGPathMoveToPoint(path, NULL,centerPoint.x, centerPoint.y);
    CGPathAddArc(path, NULL,centerPoint.x, centerPoint.y, _radius,startAngle, endAngle, 0);
    
    CGContextAddPath(context, path);
    [color setFill];    CGContextFillPath(context);
//    CGContextSetAllowsAntialiasing(context, true);
//    CGContextSetShouldAntialias(context, true);

    CGPathRelease(path);
    
}



- (void)drawFansInContext
{
    CGPoint centerPoint = CGPointMake(self.frame.size.width/2, self.frame.size.height/2);
    
    CGFloat startAngle = _angle;

    int fanCount = 10;
    
    CGFloat anglePerFan = 360.00/fanCount;
    CGFloat endAngle = anglePerFan + startAngle; 
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGFloat arcRadius = _radius/2.0;
    CGFloat arcAngle = 360.00/fanCount;

    
    for (int i=0; i<fanCount; i++)
    {
        
        //For every alternate iterations we need to draw arcs, to draw the shape like fan
        if ((i%2)==0) 
        {
//            CGContextSetAllowsAntialiasing(context, true);
//            CGContextSetShouldAntialias(context, true);

            CGFloat startAngleInRad = DEGREES_TO_RADIANS(startAngle);
            CGFloat endAngleInRad = DEGREES_TO_RADIANS(endAngle);
            
            CGFloat startPointX = _radius * cos(startAngleInRad) + centerPoint.x;
            CGFloat startPointY = _radius * sin(startAngleInRad) + centerPoint.y;
            
            CGFloat endPointX = _radius * cos(endAngleInRad) + centerPoint.x;
            CGFloat endPointY = _radius * sin(endAngleInRad) + centerPoint.y;
            
            
            
            CGFloat startArcAngle = startAngleInRad+DEGREES_TO_RADIANS(arcAngle);
            CGFloat arcStartPointX = arcRadius * cos(startArcAngle) + centerPoint.x;
            CGFloat arcStartPointY = arcRadius * sin(startArcAngle) + centerPoint.y;
            
            CGFloat endArcAngle = endAngleInRad+DEGREES_TO_RADIANS(arcAngle);
            CGFloat arcEndPointX = arcRadius * cos(endArcAngle) + centerPoint.x;
            CGFloat arcEndPointY = arcRadius * sin(endArcAngle) + centerPoint.y;
            
            
            CGMutablePathRef path = CGPathCreateMutable();
            CGPathMoveToPoint(path, NULL,centerPoint.x, centerPoint.y);
            CGPathAddQuadCurveToPoint(path, NULL, arcStartPointX, arcStartPointY, startPointX, startPointY);
            CGPathAddArc(path, NULL,centerPoint.x, centerPoint.y, _radius,startAngleInRad, endAngleInRad, 0);
            
            CGPathMoveToPoint(path, NULL,centerPoint.x, centerPoint.y);
            CGPathAddQuadCurveToPoint(path, NULL, arcEndPointX, arcEndPointY, endPointX, endPointY);
            
            
            CGContextAddPath(context, path);
            [[UIColor colorWithWhite:0.2 alpha:0.3] setFill]; 

            CGContextFillPath(context);
            CGPathRelease(path);


        }
        startAngle = startAngle+anglePerFan;
        endAngle = endAngle +anglePerFan;

    
    }
}

- (void) drawGlossyEffect
{
    CGPoint centerPoint = CGPointMake(self.frame.size.width/2, self.frame.size.height/2);

    CGContextRef context = UIGraphicsGetCurrentContext();
    CGFloat colors [] = {1.0, 1.0, 1.0, 0.0, 
                        1.0,1.0, 1.0, 0.4
        
        ,                                         
                        };
    CGFloat glossLocations[] = {0,1};
    CGColorSpaceRef baseSpace = CGColorSpaceCreateDeviceRGB();
    CGGradientRef gradient = CGGradientCreateWithColorComponents(baseSpace, colors, glossLocations,2);
    CGColorSpaceRelease(baseSpace), baseSpace = NULL;
//	CGRect rect = CGRectMake(centerPoint.x-_radius, centerPoint.y-_radius, (_radius-2)*2, _radius-10);

    CGContextSaveGState(context);
//    CGContextAddEllipseInRect(context, rect);

    CGContextAddArc(context, centerPoint.x, centerPoint.y, _radius-1, DEGREES_TO_RADIANS(190), DEGREES_TO_RADIANS(350), 0);

    CGContextClip(context);
    CGContextSetAllowsAntialiasing(context, true);
    CGContextSetShouldAntialias(context, true);

	
//    CGPoint startPoint = CGPointMake(CGRectGetMidX(rect), CGRectGetMinY(rect));
//    CGPoint endPoint = CGPointMake(CGRectGetMidX(rect), CGRectGetMaxY(rect));
//	
//    CGContextDrawLinearGradient(context, gradient, startPoint, endPoint, 0);
    CGFloat startRadius = _radius-(_radius/2.0);
    CGFloat endRadius = _radius-1;
   CGContextDrawRadialGradient(context, gradient, centerPoint, startRadius, centerPoint, endRadius, kCGGradientDrawsBeforeStartLocation);

    CGGradientRelease(gradient), gradient = NULL;
    CGContextRestoreGState(context);

}

- (void) drawEdgeCirce
{
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGPoint centerPoint = CGPointMake(self.frame.size.width/2, self.frame.size.height/2);

    CGContextAddArc(context, centerPoint.x, centerPoint.y, _radius, DEGREES_TO_RADIANS(0), DEGREES_TO_RADIANS(360), 0);
    [[UIColor colorWithWhite:0.0 alpha:0.1] set];
    CGContextSetLineWidth(context, 2.0);
    CGContextStrokePath(context);
    
}

- (void) drawShadowEffect
{
    
}

- (NSArray *) defaultColors
{
    float INCREMENT = 1.00/_segments;
    NSMutableArray *colors = [NSMutableArray array];
//    for (float hue = 0.0; hue < 1.00; hue += INCREMENT)
    for (float hue = 1.0; hue > 0.00; hue -= INCREMENT) 
    {
        UIColor *color = [UIColor colorWithHue:hue saturation:1.0 brightness:1.0 alpha:1.0];
        [colors addObject:color];
    }
    return colors;
    
    
//    return [NSArray arrayWithObjects:
//            [UIColor colorWithRed:86/255.0f green:27/255.0f blue:167/255.0f alpha:1.0],
//            [UIColor colorWithRed:218/255.0f green:29/255.0f blue:209/255.0f alpha:1.0],
//            [UIColor colorWithRed:169/255.0f green:21/255.0f blue:119/255.0f alpha:1.0],
//            [UIColor colorWithRed:214/255.0f green:45/255.0f blue:20/255.0f alpha:1.0],
//            [UIColor colorWithRed:175/255.0f green:105/255.0f blue:33/255.0f alpha:1.0],
//            [UIColor colorWithRed:164/255.0f green:218/255.0f blue:44/255.0f alpha:1.0],
//            [UIColor colorWithRed:47/255.0f green:180/255.0f blue:00/255.0f alpha:1.0],
//            [UIColor colorWithRed:35/255.0f green:219/255.0f blue:131/255.0f alpha:1.0],
//            [UIColor colorWithRed:27/255.0f green:154/255.0f blue:186/255.0f alpha:1.0],
//            [UIColor colorWithRed:40/255.0f green:58/255.0f blue:218/255.0f alpha:1.0],
//            nil];
}

- (UIColor*) colorForSegment:(NSUInteger)segmentIndex
{
    CGFloat segmentValue = _segments;
    CGFloat colorValue = 1.0 - (segmentIndex % _segments) * (1.0 / segmentValue);
    
    UIColor *color = [UIColor colorWithHue:colorValue saturation:1 brightness:0.8 alpha:1.0];
    return color;
}

#pragma mark -
#pragma mark Timer Fire Method

- (void) timerFired:(NSTimer *)timer
{
    //In timer fire method we need to change the opacity of the each stroke
//    if (_segmentIndex >= _segments) 
//    {
//        _segmentIndex = 0;
//    }
    
    [self setNeedsDisplay];
    CGFloat anglePerFan = 360.00/10.00;

    _angle = _angle+anglePerFan;
//    _segmentIndex++;
    if (_angle>=360)
    {
        _angle = 0.0;
    }
    
}

#pragma mark -
#pragma mark View LifeCycle Methods

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        [self setBackgroundColor:[UIColor whiteColor]];
        _radius = 11.00;//Default is set as 20.00
        _segments = 360;
        _angle = 0.00;
        _segmentColors = [[NSMutableArray alloc] initWithArray:[self defaultColors]];

    }
    return self;
}

- (id)init
{
    return [self initWithFrame:CGRectZero];
}


- (void)dealloc
{
    [_segmentColors release];
    [super dealloc];
}


#pragma mark -
#pragma mark View Drawing Method
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
       
    double startAngle;
    double angleForStep = 360.00/_segments;
    double angle = 180.00;
    

    for (int index=0; index<_segments; index++) 
    {
        startAngle = angle;
        angle = angle + angleForStep;
        
        //Draw the segment with known start angle and end angle
        [self drawSegmentForIndex:index startAngle:DEGREES_TO_RADIANS(startAngle) endAngle:DEGREES_TO_RADIANS(angle)];
    }
    [self drawFansInContext];

    [self drawGlossyEffect];
    //[self drawEdgeCirce];


}

#pragma mark - Spinner animation methods
- (void)startAnimation
{
//    NSLog(@"Start beach ball spinner animation");
    [super startAnimation];
//    _segmentIndex = 0;
    [_animationTimer invalidate];
    _animationTimer = [[NSTimer timerWithTimeInterval:0.20 target:self selector:@selector(timerFired:) userInfo:nil repeats:YES]retain];
    [[NSRunLoop currentRunLoop]addTimer:_animationTimer forMode:NSDefaultRunLoopMode ];

}
- (void)stopAnimation
{
//    NSLog(@"Stop beach ball spinner animation");
    //Invalidate the timer to stop the animation
    [super stopAnimation];
    [_animationTimer invalidate];

}



@end
